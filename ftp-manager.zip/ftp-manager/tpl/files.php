<?php
    $params = $_SERVER['REQUEST_URI'];
    $params = urldecode(explode('?',$params)[1]);
    $params = explode('&',$params);
    $final_params = array();
    foreach($params as $param){
        if(strpos($param,"path=") === false){
            $final_params[] = $param;
        }
    }
    $final_params = implode('&',$final_params);
?>
<p>شما اکنون اینجا هستید: <?php echo $dirPath ?></p>

<div class="frmsvr_wrap">
    <form action="admin.php?<?php echo $final_params2 ?>&action=delete" method="post" id="deleteForm">
        <table class="widefat showhidden">
            <thead>
                <tr>
                    <td class="check-column"><input type="checkbox"></td>
                    <td>نام فایل</td>
                </tr>
            </thead>
                <tbody>
                    <tr>
                        <td>&nbsp;</td>
                        <td>
                            <a href="admin.php?<?php echo $final_params . "&path={$backDir}" ?>">../</a>
                        </td>
                    </tr>
                    <?php foreach($folders as $folder): ?>
                        <tr>
                            <th class="check-column">
                                <input type="checkbox" id="<?php echo $folder['id'] ?>" name="folders[]" value="<?php echo $folder['path'] ?>">
                            </th>
                            <td>
                                <a href="admin.php?<?php echo $final_params . "&path={$folder['path']}" ?>"><?php echo $folder['name'] ?>/</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php foreach($files as $file): ?>
                        <tr class="" title="">
                            <th class="check-column">
                                <input type="checkbox" id="<?php echo $file['id'] ?>" name="files[]" value="<?php echo $file['path'] ?>">
                            </th>
                            <td>
                                <label for="<?php echo $file['id'] ?>"><?php echo $file['name'] ?></label>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
		</table>
    </form><br>
    <input form="deleteForm" type="submit" name="submit" id="deleteBtn" class="button button-primary" value="حذف">
    <input form="deleteForm" type="submit" style="background-color: #28a745; border-color: #28a745" name="submit" id="adrressBtn" class="button button-primary" value="نمایش آدرس">
    <button class="button button-primary" style="background-color: #ffc107; border-color: #ffc107; color:black" id="MakeDirBtn">ساخت پوشه</button>
    <form action="admin.php?<?php echo $final_params2 ?>&action=mkdir" method="post" id="mkdirForm">
        <input type="hidden" id="InputDirName" name="dirname">
    </form>
    
</div>