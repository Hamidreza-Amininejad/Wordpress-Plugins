<?php
    $params2 = $_SERVER['REQUEST_URI'];
    $params2 = urldecode(explode('?',$params2)[1]);
    $params2 = explode('&',$params2);
    $final_params2 = array();
    foreach($params2 as $param2){
        if(strpos($param2,"action=") === false){
            $final_params2[] = $param2;
        }
    }
    $final_params2 = implode('&',$final_params2);
?>
<div class="wrap">
    <form action="admin.php?<?php echo $final_params2 ?>&action=upload" method="post" enctype="multipart/form-data" id="uploadForm">
        <input type="file" name="ufile" style="display: none;" id="InputFile">
        <h1>مدیریت فایل ها <label for="InputFile" class="page-title-action">آپلود فایل</label></h1>
    </form>
    <?php if(isset($showMessage)): ?>
        <div class="error-div error">
            <strong><?php echo $showMessage ?></strong>
        </div>
    <?php endif; ?>
    <?php if(isset($error_warning)): ?>
        <div class="error-div error">
            <strong><?php echo $error_warning ?></strong>
        </div>
    <?php
        else:
            include mftp_tpl . "files.php";
        endif;
    ?>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function (){
    $("#InputFile").change(function (){
      document.getElementById("uploadForm").submit();
    })
    $("#adrressBtn").click(function (){
        $('#deleteForm').attr('action', 'admin.php?<?php echo $final_params2 ?>&action=getUrl');
    })
    $("#MakeDirBtn").click(function(){
        dirname = window.prompt("نام پوشه:");
        $('#InputDirName').attr('value', dirname);
        document.getElementById("mkdirForm").submit();
    })
  })
</script>