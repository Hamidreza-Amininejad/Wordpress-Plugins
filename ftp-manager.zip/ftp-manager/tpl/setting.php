<div class="wrap">
    <?php foreach($alerts as $alert): ?>
        <div class="error-div error">
            <strong><?php echo $alert ?></strong>
        </div>
    <?php endforeach; ?>
    <h1>تنظیمات پلاگین</h1>
    <form action="" method="post">
        <table class="form-table">
            <tbody>
                <tr>
                    <th>
                        <label for="InputFtpServer">آدرس ftp server:</label>
                    </th>
                    <td>
                        <input name="mftp_server" id="InputFtpServer" value="<?php echo $options['server'] ?>">
                    </td>
                </tr>

                <tr>
                    <th>
                        <label for="InputFtpPort">پورت:</label>
                    </th>
                    <td>
                        <input name="mftp_port" id="InputFtpPort" value="<?php echo $options['port'] ?>">
                    </td>
                </tr>

                <tr>
                    <th>
                        <label for="InputFtpUsername">نام کاربری:</label>
                    </th>
                    <td>
                        <input name="mftp_username" id="InputFtpUsername" value="<?php echo $options['username'] ?>">
                    </td>
                </tr>

                <tr>
                    <th>
                        <label for="InputFtpPassword">رمز عبور:</label>
                    </th>
                    <td>
                        <input name="mftp_password" id="InputFtpPassword" value="<?php echo $options['password'] ?>">
                    </td>
                </tr>

                <tr>
                    <th>
                        <label for="InputFtpPath">مسیر ftp:</label>
                    </th>
                    <td>
                        <input name="mftp_path" id="InputFtpPath" value="<?php echo $options['path'] ?>">
                    </td>
                </tr>

                <tr>
                    <th>
                        <label for="InputFtpCdn">دامنه ی cdn:</label>
                    </th>
                    <td>
                        <input name="mftp_cdn" id="InputFtpCdn" value="<?php echo $options['cdn'] ?>">
                    </td>
                </tr>
            </tbody>
        </table>
        <?php submit_button() ?>
    </form>
</div>