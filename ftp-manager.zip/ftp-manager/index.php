<?php

/*
Plugin Name: مدیریت فایل های ftp
Description: پلاگین مدیریت فایل های ftp از طریق داشبورد وردپرس
Author: راهکار هوشمند ایرانیان
Version: 1.0.0
Author URI: https://pccportal.ir/
*/

define('mftp_inc',plugin_dir_path(__FILE__)."inc/");
define('mftp_tpl',plugin_dir_path(__FILE__)."tpl/");
define('mftp_css',plugin_dir_path(__FILE__)."css/");

require mftp_inc . "manage.php";
require mftp_inc . "setting.php";
require mftp_inc . "ftp.php";

register_activation_hook(__FILE__,'mftpInstall');
register_deactivation_hook(__FILE__,'mftpUninstall');

function mftpInstall(){
    // Plugin Active   
}

function mftpUninstall(){
    // Plugin Deactive
    delete_option('mftp_config');
}

function mftp_session(){
    if(!session_id()) {
        session_start();
    }
}

add_action('admin_menu','mftpMenu');
add_action('init','mftp_session');

function mftpMenu(){
    add_menu_page(
        'مدیریت فایل های ftp',
        'مدیریت فایل های ftp',
        'manage_options',
        'ftp-manager/inc/manage.php',
        'mftp_main',
        'dashicons-open-folder',
        10
    );

    add_submenu_page(
        'ftp-manager/inc/manage.php',
        'مدیریت فایل',
        'مدیریت فایل',
        'manage_options',
        'ftp-manager/inc/manage.php',
        'mftp_main'
    );

    add_submenu_page(
        'ftp-manager/inc/manage.php',
        'تنظیمات',
        'تنظیمات',
        'manage_options',
        'ftp-manager/inc/setting.php',
        'mftp_setting'
    );
}