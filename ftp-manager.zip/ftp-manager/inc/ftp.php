<?php

class ftpController{
    protected $ftp_handle;
    protected $error;
    public function __construct($server,$port,$username,$passowrd,$path){
        $connect = @ftp_connect($server,$port);
        if($connect){
            $login = @ftp_login($connect,$username,$passowrd);
            if($login){
                $this->ftp_handle = $connect;
                if($this->checkDirExist($path)){
                    ftp_chdir($this->ftp_handle,$path);
                } else{
                    $this->error = "مسیر وارد شده درست نمی باشد";
                }
            } else{
                $this->error = "خطا در احراز هویت";
            }
        } else{
            $this->error = "خطا در برقرای ارتباط با سرور";
        }
    }

    public function getError(){
        return $this->error;
    }

    public function __destruct(){
        if($this->ftp_handle){
            ftp_close($this->ftp_handle);
        }
    }

    public function getPath(){
        $path = ftp_pwd($this->ftp_handle);
        return $path;
    }

    public function makeFolder($path,$fname){
        $here = $this->getPath();
        ftp_chdir($this->ftp_handle,$path);
        if(@ftp_mkdir($this->ftp_handle,$fname)){
            ftp_chdir($this->ftp_handle,$here);
            return true;
        }
        ftp_chdir($this->ftp_handle,$here);
        return false;
    }

    public function rename($old,$new){
        ftp_rename($this->ftp_handle,$old,$new);
    }

    public function DeleteFolder($fname){
        ftp_rmdir($this->ftp_handle,$fname);
    }

    public function getFiles($directory = "./"){
        $files = ftp_mlsd($this->ftp_handle,$directory);
        $result = array();
        foreach($files as $file){
            if($file['type'] == 'file'){
                $result[] = $file;
            }
        }
        return $result;
    }
    
    public function getFolders($directory = "./"){
        $files = ftp_mlsd($this->ftp_handle,$directory);
        $result = array();
        foreach($files as $file){
            if($file['type'] == 'dir'){
                $result[] = $file;
            }
        }
        return $result;
    }

    public function deleteFile($fname){
        ftp_delete($this->ftp_handle,$fname);
    }

    public function downloadFile($fname,$sname){
        ftp_get($this->ftp_handle,$sname,$fname,FTP_BINARY);
    }

    public function uploadFile($sname,$file,$path){
        $here = $this->getPath();
        ftp_chdir($this->ftp_handle,$path);
        if(ftp_put($this->ftp_handle,$sname,$file,FTP_BINARY)){
            ftp_chdir($this->ftp_handle,$here);
            return true;
        }
        ftp_chdir($this->ftp_handle,$here);
        return false;
    }

    public function checkDirExist($dir){
        $here = $this->getPath();
        if(@ftp_chdir($this->ftp_handle,$dir)){
            ftp_chdir($this->ftp_handle,$here);
            return true;
        }
        return false;
    }

    public function getBackPath($path){
        $here = $this->getPath();
        ftp_chdir($this->ftp_handle,$path . "/../");
        $result = $this->getPath();
        ftp_chdir($this->ftp_handle,$here);
        return $result;
    }

    public function showPath($dir){
        $here = $this->getPath();
        ftp_chdir($this->ftp_handle,$dir);
        $path = $this->getPath();
        ftp_chdir($this->ftp_handle,$here);
        return $path;
    }

    public function deleteFiles($files){
        $errors = array();
        foreach($files as $file){
            if(ftp_size($this->ftp_handle,$file) != -1){
                $this->deleteFile($file);
            } else{
                $file_error = end(explode("/",$file));
                $errors[] = "فایل <b>{$file_error}</b> حذف نشد";
            }
        }
        return $errors;
    }

    public function deleteFolders($folders){
        $errors = array();
        foreach($folders as $folder){
            if($this->checkDirExist($folder)){
                $this->DeleteFolder($folder);
            } else{
                $folder_error = end(explode("/",$folder));
                $errors[] = "فولدر <b>{$folder_error}</b> حذف نشد";
            }
        }
        return $errors;
    }

    public function getUrlFile($path,$file,$cdn){
        $file = explode('/',$file);
        $filename = array();
        foreach($file as $value){
            if($value != '..' && $value != "." && $value != ''){
                $filename[] = $value;
            }
        }
        $filename = implode("/",$filename);

        $path = explode('/',$path);
        $pathname = array();
        foreach($path as $value2){
            if($value2 != '..' && $value2 != "." && $value2 != ''){
                $pathname[] = $value2;
            }
        }
        $pathname = implode("/",$pathname);
        $result = str_replace($pathname,'',$filename);
        $result = $cdn . $result;
        return $result;
    }

    public function getUrlFiles($path,$files,$cdn){
        $result = array();
        foreach($files as $file){
            if(ftp_size($this->ftp_handle,$file) != -1){
                $result[] = $this->getUrlFile($path,$file,$cdn);
            } else{
                $result[] = 'فایل ' . htmlspecialchars($file) . ' یافت نشد';
            }
        }
        $result = implode('<br>',$result);
        return $result;
    }
}