<?php

function mftp_main(){
    $options = (array) json_decode(get_option('mftp_config'), true);
    if(isset($options['server']) && isset($options['port']) && isset($options['username']) && isset($options['password']) && isset($options['path'])){
        $ftp = new ftpController($options['server'],$options['port'],$options['username'],$options['password'],$options['path']);
        $errors = $ftp->getError();
        if(!$errors){
            // connect success
            $path = (isset($_GET['path'])) ? $_GET['path'] : './';
            $checkPath = $ftp->checkDirExist($path);
            if($checkPath){
                if(isset($_SESSION['message'])){
                    $showMessage = $_SESSION['message'];
                    unset($_SESSION['message']);
                }
                $path = (end(str_split($path)) == "/") ? $path : $path . "/";
                $action = (isset($_GET['action'])) ? $_GET['action'] : '';
                switch($action){
                    case 'upload':
                        if(isset($_FILES['ufile'])){
                            $uploadFile = $_FILES['ufile']['tmp_name'];
                            $fileName = $_FILES['ufile']['name'];
                            $upload = $ftp->uploadFile($fileName,$uploadFile,$path);
                            if($upload){
                                $_SESSION['message'] = "فایل مورد نظر شما با موفقیت آپلود شد";
                            } else{
                                $_SESSION['message'] = "مشکل در فرآیند آپلود فایل";
                            }
                        } else{
                            $_SESSION['message'] = "مشکل در فرآیند آپلود فایل";
                        }
                        $params3 = $_SERVER['REQUEST_URI'];
                        $params3 = urldecode(explode('?',$params3)[1]);
                        $params3 = explode('&',$params3);
                        $final_params3 = array();
                        foreach($params3 as $param3){
                            if(strpos($param3,"action=") === false){
                                $final_params3[] = $param3;
                            }
                        }
                        $final_params3 = implode('&',$final_params3);
                        exit("<script>window.location = 'admin.php?{$final_params3}'</script>");
                    break;

                    case 'delete':
                        if((isset($_POST['files']) || isset($_POST['folders'])) && (is_array($_POST['files']) || is_array($_POST['folders']))){
                            $files = (isset($_POST['files'])) ? $_POST['files'] : array();
                            $folders = (isset($_POST['folders'])) ? $_POST['folders'] : array();
                            $deleteFiles = $ftp->deleteFiles($files);
                            $deleteFolders = $ftp->deleteFolders($folders);
                            if(count($deleteFiles)){
                                foreach($deleteFiles as $errorDelete){
                                    $_SESSION['message'] .= $errorDelete . '<br>';
                                }
                            } else{
                                $_SESSION['message'] .= "فایل های مورد نظر با موفقیت پاک شدند<br>";
                            }

                            if(count($deleteFolders)){
                                foreach($deleteFolders as $deleteFolder){
                                    $_SESSION['message'] .= $deleteFolder . '<br>';
                                }
                            } else{
                                $_SESSION['message'] .= "پوشه های مورد نظر با موفقیت پاک شدند";
                            }                           
                        } else{
                            $_SESSION['message'] = "خطا در هنگام حذف فایل ها";
                        }
                        $params3 = $_SERVER['REQUEST_URI'];
                        $params3 = urldecode(explode('?',$params3)[1]);
                        $params3 = explode('&',$params3);
                        $final_params3 = array();
                        foreach($params3 as $param3){
                            if(strpos($param3,"action=") === false){
                                $final_params3[] = $param3;
                            }
                        }
                        $final_params3 = implode('&',$final_params3);
                        exit("<script>window.location = 'admin.php?{$final_params3}'</script>");
                    break;

                    case 'getUrl':
                        if((isset($options['path']) && !empty($options['path'])) && (isset($options['cdn']) && !empty($options['cdn']))){
                            if(isset($_POST['files']) && !empty($_POST['files']) && is_array($_POST['files'])){
                                $showFileUrl = $ftp->getUrlFiles($options['path'],$_POST['files'],$options['cdn']);
                                $_SESSION['message'] = $showFileUrl;
                            } else{
                                $_SESSION['message'] = "فایلی برای انجام عملیات انتخاب نشده است";
                            }
                        } else{
                            $_SESSION['message'] = "تنظیمات پلاگین به درستی کانفیگ نشده است";
                        }
                        $params3 = $_SERVER['REQUEST_URI'];
                        $params3 = urldecode(explode('?',$params3)[1]);
                        $params3 = explode('&',$params3);
                        $final_params3 = array();
                        foreach($params3 as $param3){
                            if(strpos($param3,"action=") === false){
                                $final_params3[] = $param3;
                            }
                        }
                        $final_params3 = implode('&',$final_params3);
                        exit("<script>window.location = 'admin.php?{$final_params3}'</script>");
                    break;

                    case 'mkdir':
                        if(isset($_POST['dirname']) && !empty($_POST['dirname']) && strlen($_POST['dirname']) < 255){
                            if($ftp->makeFolder($path,$_POST['dirname'])){
                                $_SESSION['message'] = "پوشه مورد نظر با موفقیت ایجاد شد";
                            } else{
                                $_SESSION['message'] = "پوشه مورد نظر را نمی توان ساخت";
                            }
                        } else{
                            $_SESSION['message'] = "نام پوشه به درستی انتخاب نشده است";
                        }
                        $params3 = $_SERVER['REQUEST_URI'];
                        $params3 = urldecode(explode('?',$params3)[1]);
                        $params3 = explode('&',$params3);
                        $final_params3 = array();
                        foreach($params3 as $param3){
                            if(strpos($param3,"action=") === false){
                                $final_params3[] = $param3;
                            }
                        }
                        $final_params3 = implode('&',$final_params3);
                        exit("<script>window.location = 'admin.php?{$final_params3}'</script>");
                    break;
                    
                    default:
                       $folders = array();
                       $files = array();
                       $getfolders = $ftp->getFolders($path);
                       $getfiles = $ftp->getFiles($path);
                       $backDir = $ftp->getBackPath($path);
                       $dirPath = $ftp->showPath($path);

                       foreach($getfolders as $key => $folder){
                           $folder['id'] = 'folder-' . $key;
                           $folder['path'] = $path . $folder['name']; 
                           $folders[] = $folder;
                       }
                       foreach($getfiles as $key => $file){
                            $file['id'] = 'file-' . $key;
                            $file['path'] = $path . $file['name'];
                            $files[] = $file;
                        }
                }
            } else{
                $error_warning = "مسیر مورد نظر شما یافت نشد";
            }
        } else{
            // connect fail
            $error_warning = "خطا در اتصال به سرور";
        }
    } else{
        $error_warning = "خطا در اتصال به سرور";
    }

    include mftp_tpl . "filemanager.php";
}