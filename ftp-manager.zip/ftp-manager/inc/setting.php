<?php

function mftp_setting(){
    $alerts = array();
    if(isset($_POST['submit'])){
        $error = mftp_validate_setting();
        if($error){
            foreach($error as $value){
                $alerts[] = $value;
            }
            $options = [
                'server' => (isset($_POST['mftp_server'])) ? htmlspecialchars($_POST['mftp_server']) : '',
                'port' => (isset($_POST['mftp_port'])) ? htmlspecialchars($_POST['mftp_port']) : '',
                'username' => (isset($_POST['mftp_username'])) ? htmlspecialchars($_POST['mftp_username']) : '',
                'password' => (isset($_POST['mftp_password'])) ? htmlspecialchars($_POST['mftp_password']) : '',
                'path' => (isset($_POST['mftp_path'])) ? htmlspecialchars($_POST['mftp_path']) : '',
                'cdn' => (isset($_POST['mftp_cdn'])) ? htmlspecialchars($_POST['mftp_cdn']) : '',
            ];
        } else{
            $mftp_server = htmlspecialchars($_POST['mftp_server']);
            $mftp_port = htmlspecialchars($_POST['mftp_port']);
            $mftp_username = htmlspecialchars($_POST['mftp_username']);
            $mftp_password = htmlspecialchars($_POST['mftp_password']);
            $mftp_path = htmlspecialchars($_POST['mftp_path']);
            $mftp_cdn = (isset($_POST['mftp_cdn'])) ? htmlspecialchars($_POST['mftp_cdn']) : '';

            $ftp = new ftpController($mftp_server,$mftp_port,$mftp_username,$mftp_password,$mftp_path);
            $check = $ftp->getError();

            $options = [
                'server' => $mftp_server,
                'port' => $mftp_port,
                'username' => $mftp_username,
                'password' => $mftp_password,
                'path' => $mftp_path,
                'cdn' => $mftp_cdn
            ];
            if(!$check){
                // connect success
                $alerts[] = "ارتباط با موفقیت برقرار شد";
                update_option('mftp_config',json_encode($options));
            } else{
                // connect fail
                $alerts[] = $check;
            }
        }
    } else{
        $options = get_option('mftp_config');
        $options = (array) json_decode($options, true);
        if(!(isset($options['server']) && isset($options['port']) && isset($options['username']) && isset($options['password']) && isset($options['path']) && isset($options['cdn']))){
            $options = [
                'server' => (isset($options['server'])) ? $options['server'] : '',
                'port' => (isset($options['port'])) ? $options['port'] : '',
                'username' => (isset($options['username'])) ? $options['username'] : '',
                'password' => (isset($options['password'])) ? $options['password'] : '',
                'path' => (isset($options['path'])) ? $options['path'] : '',
                'cdn' => (isset($options['cdn'])) ? $options['cdn'] : '',
            ];
        }
    }

    include mftp_tpl . "setting.php";
}

function mftp_validate_setting(){
    $error = array();
    if(!isset($_POST['mftp_server']) || empty($_POST['mftp_server']) || strlen($_POST['mftp_server']) > 250){
        $error['mftp_server'] = "آدرس سرور به درستی وارد نشده است";
    }
    if(!isset($_POST['mftp_port']) || empty($_POST['mftp_port']) || !is_numeric($_POST['mftp_port'])){
        $error['mftp_port'] = "پورت به درستی وارد نشده است";
    }
    if(!isset($_POST['mftp_username']) || empty($_POST['mftp_username']) || strlen($_POST['mftp_username']) > 250){
        $error['mftp_username'] = "نام کاربری به درستی وارد نشده است";
    }
    if(!isset($_POST['mftp_password']) || strlen($_POST['mftp_password']) > 250){
        $error['mftp_password'] = "رنز عبور به درستی وارد نشده است";
    }
    if(!isset($_POST['mftp_path']) || strlen($_POST['mftp_path']) > 250 || strlen($_POST['mftp_path']) < 1){
        $error['mftp_path'] = "مسیر ftp به درستی مشخص نشده است";
    }
    if((isset($_POST['mftp_cdn']) && !empty($_POST['mftp_cdn'])) && !filter_var($_POST['mftp_cdn'], FILTER_VALIDATE_URL)){
        $error['mftp_cdn'] = "فرمت url وارد شده صحیح نیست";
    }

    return $error;
}